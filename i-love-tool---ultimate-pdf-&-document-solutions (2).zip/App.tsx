
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import ToolPage from './pages/ToolPage';
import LegalPage from './pages/LegalPage';
import Contact from './pages/Contact';
import Admin from './pages/Admin';
import Blog from './pages/Blog';
import BlogPostPage from './pages/BlogPostPage';

const App: React.FC = () => {
  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-[#f3f3f3]">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/about" element={<LegalPage title="About Us" type="about" />} />
            <Route path="/privacy" element={<LegalPage title="Privacy Policy" type="privacy" />} />
            <Route path="/terms" element={<LegalPage title="Terms & Conditions" type="terms" />} />
            <Route path="/disclaimer" element={<LegalPage title="Legal Disclaimer" type="disclaimer" />} />
            <Route path="/copyright" element={<LegalPage title="Copyright Notice" type="copyright" />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPostPage />} />
            {/* Catch-all for tools using slug */}
            <Route path="/:slug" element={<ToolPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
