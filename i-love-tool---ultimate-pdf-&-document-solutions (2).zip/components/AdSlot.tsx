
import React, { useEffect, useRef } from 'react';

interface AdSlotProps {
  slotId: 'globalHeader' | 'aboveContent' | 'belowContent' | 'footer' | 'sidebar';
  className?: string;
}

const AdSlot: React.FC<AdSlotProps> = ({ slotId, className = "" }) => {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only run if adRef.current exists
    if (!adRef.current) return;

    try {
      const adsJson = localStorage.getItem('site_ads');
      if (adsJson) {
        const ads = JSON.parse(adsJson);
        const code = ads[slotId];
        
        if (code && typeof code === 'string' && code.trim() !== '') {
          // Clear and Inject safely
          const container = adRef.current;
          container.innerHTML = '';
          
          const range = document.createRange();
          range.selectNode(container);
          const documentFragment = range.createContextualFragment(code);
          container.appendChild(documentFragment);
          
          // Trigger AdSense if present
          try {
            (window as any).adsbygoogle = (window as any).adsbygoogle || [];
            (window as any).adsbygoogle.push({});
          } catch (adsenseErr) {}
        }
      }
    } catch (err) {
      // Catch errors silently so the rest of the app doesn't crash
      console.warn('AdSlot error handled gracefully:', err);
    }
  }, [slotId]);

  return (
    <div 
      ref={adRef} 
      className={`ad-slot-container flex justify-center items-center overflow-hidden min-h-[1px] ${className}`}
      style={{ display: 'block', width: '100%' }}
    >
      {/* Ad content injected via useEffect */}
    </div>
  );
};

export default AdSlot;
