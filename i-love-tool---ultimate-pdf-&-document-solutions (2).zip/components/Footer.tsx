
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-16 pb-8 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h4 className="text-red-600 font-bold uppercase text-xs tracking-widest mb-4">I l❤️ve Tool</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/" className="hover:text-red-600">Home</Link></li>
              <li><Link to="/about" className="hover:text-red-600">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-red-600">Contact</Link></li>
              <li><Link to="/privacy" className="hover:text-red-600">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-red-600">Terms of Service</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-red-600 font-bold uppercase text-xs tracking-widest mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/disclaimer" className="hover:text-red-600">Disclaimer</Link></li>
              <li><Link to="/copyright" className="hover:text-red-600">Copyright</Link></li>
              <li><Link to="/contact" className="hover:text-red-600">Support Center</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-red-600 font-bold uppercase text-xs tracking-widest mb-4">Solutions</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/unlock-pdf" className="hover:text-red-600">Unlock PDF</Link></li>
              <li><Link to="/protect-pdf" className="hover:text-red-600">Protect PDF</Link></li>
              <li><Link to="/repair-pdf" className="hover:text-red-600">Repair PDF</Link></li>
            </ul>
          </div>
          <div className="flex flex-col items-start">
            <h4 className="text-red-600 font-bold uppercase text-xs tracking-widest mb-4">Connect</h4>
            <div className="flex space-x-4 mb-6">
              <a href="#" className="text-gray-400 hover:text-red-600"><i className="fab fa-facebook-f"></i></a>
              <a href="#" className="text-gray-400 hover:text-red-600"><i className="fab fa-twitter"></i></a>
              <a href="#" className="text-gray-400 hover:text-red-600"><i className="fab fa-linkedin-in"></i></a>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              &copy; 2024 I l❤️ve Tool. All rights reserved. Professional PDF processing since 2024.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
