
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: 'Merge PDF', href: '/merge-pdf' },
    { label: 'Split PDF', href: '/split-pdf' },
    { label: 'Compress PDF', href: '/compress-pdf' },
    { label: 'Convert PDF', href: '/pdf-to-word' },
    { label: 'All Tools', href: '/' }
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-black tracking-tighter text-gray-800 flex items-center">
                I l<span className="text-[#e5322d] mx-0.5">❤️</span>ve Tool
              </span>
            </Link>
            <div className="hidden md:ml-10 md:flex md:space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  to={link.href}
                  className="inline-flex items-center px-1 pt-1 text-[11px] font-black text-gray-700 hover:text-[#e5322d] uppercase tracking-tighter transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <Link 
              to="/admin" 
              className="bg-[#e5322d] text-white px-5 py-2 rounded-md text-xs font-black uppercase tracking-widest hover:bg-[#c42723] transition-all"
            >
              Admin Login
            </Link>
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500"
            >
              <i className={`fa-solid ${isOpen ? 'fa-xmark' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-2">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.href}
              className="block px-4 py-3 text-sm font-bold text-gray-700 hover:bg-gray-50 hover:text-[#e5322d]"
              onClick={() => setIsOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="mt-4 px-4 pb-6">
            <Link to="/admin" className="block w-full text-center py-3 bg-[#e5322d] text-white font-black rounded-lg uppercase text-xs" onClick={() => setIsOpen(false)}>
              Admin Login
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Header;
