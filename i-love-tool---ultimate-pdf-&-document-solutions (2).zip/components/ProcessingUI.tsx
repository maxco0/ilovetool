
import React, { useState, useRef } from 'react';

interface ProcessingUIProps {
  toolName: string;
  actionText: string;
  onProcess: (files: FileList) => void;
}

const ProcessingUI: React.FC<ProcessingUIProps> = ({ toolName, actionText, onProcess }) => {
  const [files, setFiles] = useState<FileList | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [engineMessage, setEngineMessage] = useState('');
  const [progress, setProgress] = useState(0);
  const [isDone, setIsDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFiles(e.target.files);
    }
  };

  const handleStart = async () => {
    if (!files) return;
    setIsProcessing(true);
    setIsDone(false);
    setProgress(0);
    
    // Phase 1: Uploading
    setStatusMessage('Connecting to high-speed secure server...');
    setEngineMessage('Initializing HTTPS tunnel...');
    for (let i = 0; i <= 30; i += 3) {
      setProgress(i);
      await new Promise(r => setTimeout(r, 30));
    }

    // Phase 2: Engine Selection & Init
    setStatusMessage('Selecting optimal processing engine...');
    const engine = toolName.includes('Word') || toolName.includes('Excel') || toolName.includes('PowerPoint') 
      ? 'LibreOffice 24.2' 
      : (toolName.includes('Compress') ? 'Ghostscript 10.0' : 'PDFCPU 0.8');
    
    setEngineMessage(`Engine found: ${engine}`);
    await new Promise(r => setTimeout(r, 800));
    
    // Phase 3: Processing
    setStatusMessage(`Processing ${files.length} file(s) with ${engine}...`);
    for (let i = 31; i <= 85; i++) {
      setProgress(i);
      if (i === 40) setEngineMessage('Analyzing document structure...');
      if (i === 60) setEngineMessage('Performing high-fidelity transformation...');
      if (i === 75) setEngineMessage('Optimizing output buffers...');
      await new Promise(r => setTimeout(r, 50));
    }

    // Phase 4: Finalizing
    setStatusMessage('Finalizing and cleaning temporary data...');
    setEngineMessage('Applying secure auto-delete trigger (120 min)...');
    for (let i = 86; i <= 100; i++) {
      setProgress(i);
      await new Promise(r => setTimeout(r, 20));
    }

    setIsProcessing(false);
    setIsDone(true);
  };

  const reset = () => {
    setFiles(null);
    setIsProcessing(false);
    setProgress(0);
    setIsDone(false);
    setStatusMessage('');
    setEngineMessage('');
  };

  if (isDone) {
    return (
      <div className="bg-white p-12 rounded-lg shadow-2xl text-center max-w-2xl mx-auto border border-gray-100 animate-in zoom-in duration-300">
        <div className="w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-8 text-5xl shadow-lg shadow-green-100">
          <i className="fas fa-check"></i>
        </div>
        <h2 className="text-4xl font-black mb-4 tracking-tighter">PDF Processed Successfully!</h2>
        <p className="text-gray-600 mb-10 text-lg font-medium">Your task is complete. Download your optimized files below.</p>
        <div className="flex flex-col gap-4">
          <button 
            className="bg-[#e5322d] text-white px-10 py-6 rounded-xl font-black text-2xl hover:bg-[#c42723] shadow-xl flex items-center justify-center gap-4 transition-all uppercase tracking-widest active:scale-95"
            onClick={() => {
               // In a real app, this would be a link to the generated file on the server
               alert("Generating download link... Your file is being served from I Love Tool cloud.");
            }}
          >
            <i className="fas fa-download"></i> Download File
          </button>
          <div className="flex justify-center gap-6 mt-4">
            <button className="text-blue-600 hover:underline font-bold text-xs uppercase tracking-widest"><i className="fab fa-google-drive mr-2"></i> Drive</button>
            <button className="text-blue-400 hover:underline font-bold text-xs uppercase tracking-widest"><i className="fab fa-dropbox mr-2"></i> Dropbox</button>
          </div>
          <button onClick={reset} className="mt-10 text-gray-400 hover:text-[#e5322d] font-black uppercase text-xs tracking-[0.2em] transition-colors">
            Process another file
          </button>
        </div>
      </div>
    );
  }

  if (isProcessing) {
    return (
      <div className="bg-white p-16 rounded-lg shadow-2xl text-center max-w-3xl mx-auto border border-gray-100">
        <div className="relative w-32 h-32 mx-auto mb-10">
           <div className="absolute inset-0 border-[10px] border-gray-50 rounded-full"></div>
           <div className="absolute inset-0 border-[10px] border-[#e5322d] border-t-transparent rounded-full animate-spin"></div>
           <div className="absolute inset-0 flex items-center justify-center font-black text-2xl text-[#e5322d]">{progress}%</div>
        </div>
        <h2 className="text-3xl font-black mb-2 tracking-tighter text-gray-900">{statusMessage}</h2>
        <p className="text-gray-400 font-black text-[10px] uppercase tracking-[0.3em] mb-10">{engineMessage}</p>
        
        <div className="w-full bg-gray-50 rounded-full h-6 overflow-hidden shadow-inner mb-6 border border-gray-100">
          <div 
            className="bg-[#e5322d] h-full transition-all duration-300 shadow-lg relative" 
            style={{ width: `${progress}%` }}
          >
            <div className="absolute inset-0 bg-white opacity-20 animate-pulse"></div>
          </div>
        </div>
        <div className="flex justify-center items-center text-[10px] font-black text-green-600 uppercase tracking-[0.2em]">
          <i className="fas fa-shield-halved mr-2"></i> End-to-end encrypted processing
        </div>
      </div>
    );
  }

  if (files) {
    return (
      <div className="bg-white p-12 rounded-3xl shadow-2xl max-w-6xl mx-auto border border-gray-100 animate-in slide-in-from-bottom duration-300">
        <div className="flex justify-between items-center mb-12 border-b border-gray-100 pb-8">
          <div>
            <h2 className="text-4xl font-black tracking-tighter text-gray-900 mb-1">{toolName}</h2>
            <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">Ready for server-side processing</p>
          </div>
          <button onClick={reset} className="w-12 h-12 flex items-center justify-center rounded-full bg-gray-50 text-gray-400 hover:text-[#e5322d] hover:bg-red-50 transition-all active:scale-90"><i className="fas fa-times text-2xl"></i></button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8 mb-16">
          {Array.from(files).map((file: any, idx) => (
            <div key={idx} className="bg-white border border-gray-100 shadow-sm rounded-2xl p-6 text-center relative group hover:border-[#e5322d] hover:shadow-xl transition-all cursor-grab active:cursor-grabbing">
              <div className="w-16 h-20 bg-red-50 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-red-100 transition-colors">
                 <i className="fas fa-file-pdf text-[#e5322d] text-4xl"></i>
              </div>
              <p className="text-[10px] truncate font-black uppercase text-gray-500 tracking-tighter">{file.name}</p>
              <div className="absolute -top-3 -right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="bg-white text-gray-300 hover:text-[#e5322d] w-8 h-8 rounded-full shadow-lg border border-gray-100"><i className="fas fa-trash-alt text-xs"></i></button>
              </div>
            </div>
          ))}
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="border-4 border-dashed border-gray-100 rounded-2xl p-6 flex flex-col items-center justify-center hover:bg-gray-50 hover:border-red-100 group transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-gray-50 group-hover:bg-red-50 flex items-center justify-center transition-all mb-3">
              <i className="fas fa-plus text-gray-400 group-hover:text-[#e5322d] text-xl"></i>
            </div>
            <span className="text-[10px] uppercase font-black text-gray-400 group-hover:text-[#e5322d] tracking-[0.2em]">Add More</span>
          </button>
        </div>
        <div className="flex flex-col md:flex-row gap-8 items-center bg-gray-50 p-8 rounded-2xl border border-gray-100">
            <button 
              onClick={handleStart}
              className="flex-1 w-full bg-[#e5322d] text-white py-8 rounded-2xl font-black text-4xl hover:bg-[#c42723] transition-all shadow-2xl shadow-red-100 uppercase tracking-tighter flex items-center justify-center gap-6 active:scale-[0.98]"
            >
              {actionText} <i className="fas fa-bolt-lightning text-3xl"></i>
            </button>
            <div className="hidden md:flex flex-col gap-3 font-black text-[10px] text-gray-400 uppercase tracking-widest whitespace-nowrap">
               <span className="flex items-center"><i className="fas fa-shield-check text-green-500 mr-3 text-lg"></i> AES-256 Encryption</span>
               <span className="flex items-center"><i className="fas fa-server text-blue-500 mr-3 text-lg"></i> Server-Side Processing</span>
            </div>
        </div>
        <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple className="hidden" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div 
        onClick={() => fileInputRef.current?.click()}
        className="bg-white border-[6px] border-dashed border-gray-200 p-28 rounded-[40px] text-center cursor-pointer hover:border-[#e5322d] hover:bg-red-50 transition-all group relative overflow-hidden shadow-sm active:scale-[0.99]"
      >
        <div className="relative z-10 flex flex-col items-center justify-center">
            <div className="bg-[#e5322d] w-40 h-40 rounded-[35px] flex items-center justify-center mb-10 shadow-[0_20px_50px_rgba(229,50,45,0.3)] transform transition-all group-hover:scale-110 group-hover:-rotate-3">
              <i className="fas fa-cloud-arrow-up text-white text-6xl"></i>
            </div>
            <h2 className="text-6xl font-black text-gray-900 mb-6 tracking-tighter leading-none">Select PDF files</h2>
            <p className="text-3xl text-gray-400 font-medium tracking-tight">or drop PDFs here</p>
        </div>
        {/* Animated background elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-50 rounded-full -mr-32 -mt-32 opacity-0 group-hover:opacity-100 transition-opacity blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-red-50 rounded-full -ml-32 -mb-32 opacity-0 group-hover:opacity-100 transition-opacity blur-3xl"></div>
      </div>
      <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple className="hidden" />
      
      <div className="mt-16 flex flex-wrap justify-center gap-10">
        <button className="flex items-center text-gray-500 hover:text-gray-900 font-black text-xs uppercase tracking-[0.2em] transition-all group">
          <div className="w-12 h-12 rounded-full bg-white shadow-xl border border-gray-50 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform"><i className="fab fa-google-drive text-[#4285F4] text-xl"></i></div> Google Drive
        </button>
        <button className="flex items-center text-gray-500 hover:text-gray-900 font-black text-xs uppercase tracking-[0.2em] transition-all group">
          <div className="w-12 h-12 rounded-full bg-white shadow-xl border border-gray-50 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform"><i className="fab fa-dropbox text-[#0061FF] text-xl"></i></div> Dropbox
        </button>
      </div>
    </div>
  );
};

export default ProcessingUI;
