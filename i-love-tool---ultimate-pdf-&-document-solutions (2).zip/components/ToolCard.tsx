
import React from 'react';
import { Link } from 'react-router-dom';
import { PDFTool } from '../types';

interface ToolCardProps {
  tool: PDFTool;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  if (!tool) return null;
  
  return (
    <Link 
      to={`/${tool.slug}`}
      className="bg-white p-6 flex flex-col items-start text-left ilove-shadow transition-all duration-200 border border-gray-50 hover:border-red-100 group h-full rounded-lg"
    >
      <div className={`w-14 h-14 flex items-center justify-center mb-4 rounded-xl text-white text-2xl ${tool.color} shadow-lg transition-transform group-hover:scale-110 group-hover:rotate-3`}>
        <i className={`fas ${tool.icon}`}></i>
      </div>
      <h3 className="text-lg font-black text-[#1a1a1a] mb-2 leading-tight tracking-tight group-hover:text-red-600 transition-colors">{tool.name}</h3>
      <p className="text-sm text-gray-400 leading-snug font-medium line-clamp-3">{tool.description}</p>
    </Link>
  );
};

export default ToolCard;
