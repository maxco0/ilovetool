
import { PDFTool, ToolCategory, BlogPost } from './types';

export const DEFAULT_TOOLS: PDFTool[] = [
  { id: 'merge-pdf', name: 'Merge PDF', description: 'Combine PDFs in the order you want with the easiest PDF merger available.', icon: 'fa-layer-group', category: ToolCategory.ORGANIZE, slug: 'merge-pdf', color: 'bg-red-500' },
  { id: 'split-pdf', name: 'Split PDF', description: 'Separate one page or a whole set for easy conversion into independent PDF files.', icon: 'fa-scissors', category: ToolCategory.ORGANIZE, slug: 'split-pdf', color: 'bg-orange-500' },
  { id: 'compress-pdf', name: 'Compress PDF', description: 'Reduce file size while optimizing for maximal PDF quality.', icon: 'fa-compress-arrows-alt', category: ToolCategory.OPTIMIZE, slug: 'compress-pdf', color: 'bg-blue-500' },
  { id: 'pdf-to-word', name: 'PDF to Word', description: 'Easily convert your PDF files into easy to edit DOC and DOCX documents.', icon: 'fa-file-word', category: ToolCategory.CONVERT_TO, slug: 'pdf-to-word', color: 'bg-blue-600' },
  { id: 'word-to-pdf', name: 'Word to PDF', description: 'Make DOC and DOCX files easy to read by converting them to PDF.', icon: 'fa-file-pdf', category: ToolCategory.CONVERT_FROM, slug: 'word-to-pdf', color: 'bg-blue-700' },
  { id: 'pdf-to-excel', name: 'PDF to Excel', description: 'Pull data straight from PDFs into Excel spreadsheets in a few short seconds.', icon: 'fa-file-excel', category: ToolCategory.CONVERT_TO, slug: 'pdf-to-excel', color: 'bg-green-600' },
  { id: 'excel-to-pdf', name: 'Excel to PDF', description: 'Make Excel spreadsheets easy to read by converting them to PDF.', icon: 'fa-file-pdf', category: ToolCategory.CONVERT_FROM, slug: 'excel-to-pdf', color: 'bg-green-700' },
  { id: 'pdf-to-powerpoint', name: 'PDF to PowerPoint', description: 'Turn your PDF files into easy to edit PPT and PPTX slideshows.', icon: 'fa-file-powerpoint', category: ToolCategory.CONVERT_TO, slug: 'pdf-to-powerpoint', color: 'bg-orange-700' },
  { id: 'powerpoint-to-pdf', name: 'PowerPoint to PDF', description: 'Make PPT and PPTX slideshows easy to view by converting them to PDF.', icon: 'fa-file-pdf', category: ToolCategory.CONVERT_FROM, slug: 'powerpoint-to-pdf', color: 'bg-orange-800' },
  { id: 'pdf-to-jpg', name: 'PDF to JPG', description: 'Extract all images from a PDF or convert each page to a JPG image.', icon: 'fa-image', category: ToolCategory.CONVERT_TO, slug: 'pdf-to-jpg', color: 'bg-yellow-500' },
  { id: 'jpg-to-pdf', name: 'JPG to PDF', description: 'Convert JPG, PNG, BMP, GIF and TIFF images to PDF.', icon: 'fa-file-image', category: ToolCategory.CONVERT_FROM, slug: 'jpg-to-pdf', color: 'bg-yellow-600' },
  { id: 'unlock-pdf', name: 'Unlock PDF', description: 'Remove PDF password security, giving you freedom to use your PDFs.', icon: 'fa-unlock-alt', category: ToolCategory.SECURITY, slug: 'unlock-pdf', color: 'bg-indigo-600' },
  { id: 'protect-pdf', name: 'Protect PDF', description: 'Protect PDF files with a password. Encrypt PDF documents safely.', icon: 'fa-lock', category: ToolCategory.SECURITY, slug: 'protect-pdf', color: 'bg-indigo-700' },
  { id: 'rotate-pdf', name: 'Rotate PDF', description: 'Rotate your PDFs the way you need them. Even rotate multiple at once!', icon: 'fa-redo', category: ToolCategory.ORGANIZE, slug: 'rotate-pdf', color: 'bg-pink-600' },
  { id: 'watermark-pdf', name: 'Watermark PDF', description: 'Stamp an image or text over your PDF in seconds easily.', icon: 'fa-stamp', category: ToolCategory.EDIT, slug: 'watermark-pdf', color: 'bg-teal-600' },
  { id: 'page-numbers', name: 'Add Page Numbers', description: 'Add page numbers into PDFs with ease. Choose typography and size.', icon: 'fa-list-ol', category: ToolCategory.EDIT, slug: 'page-numbers', color: 'bg-cyan-600' },
  { id: 'organize-pdf', name: 'Organize PDF', description: 'Sort, add and delete PDF pages. Drag and drop to rearrange.', icon: 'fa-th-large', category: ToolCategory.ORGANIZE, slug: 'organize-pdf', color: 'bg-red-700' },
  { id: 'repair-pdf', name: 'Repair PDF', description: 'Recover data from a corrupted or damaged PDF document.', icon: 'fa-wrench', category: ToolCategory.OPTIMIZE, slug: 'repair-pdf', color: 'bg-gray-700' }
];

export const DEFAULT_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'Why I l❤️ve Tool is the Best iLovePDF Alternative in 2024',
    slug: 'best-ilovepdf-alternative-2024',
    date: 'May 15, 2024',
    author: 'Nazibul',
    readTime: '8 min',
    excerpt: 'Discover why professional users are switching to I l❤️ve Tool for faster processing and 100% free tasks.',
    content: '<h2>The Shift in PDF Management</h2><p>Our backend uses a distributed serverless architecture for maximum speed...</p>'
  }
];

export const getTools = (): PDFTool[] => {
  let custom: PDFTool[] = [];
  try {
    const raw = localStorage.getItem('custom_tools');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        custom = parsed;
      }
    }
  } catch (e) {
    console.error("Critical error in getTools:", e);
  }
  // Return baseline tools PLUS any custom ones. Never empty.
  return [...DEFAULT_TOOLS, ...custom];
};

export const getBlogPosts = (): BlogPost[] => {
  let custom: BlogPost[] = [];
  try {
    const raw = localStorage.getItem('blog_posts');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        custom = parsed;
      }
    }
  } catch (e) {
    console.error("Critical error in getBlogPosts:", e);
  }
  return [...DEFAULT_POSTS, ...custom];
};
