
import React, { useState } from 'react';

const Admin: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'ads' | 'tools' | 'posts'>('ads');

  const [ads, setAds] = useState(() => {
    const saved = localStorage.getItem('site_ads');
    return saved ? JSON.parse(saved) : { globalHeader: '', aboveContent: '', belowContent: '', footer: '', sidebar: '' };
  });

  const [newTool, setNewTool] = useState({ name: '', description: '', slug: '', icon: 'fa-file-pdf', color: 'bg-red-500' });
  const [customTools, setCustomTools] = useState<any[]>(() => {
    const saved = localStorage.getItem('custom_tools');
    return saved ? JSON.parse(saved) : [];
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'nazibulmaxco1@gmail.com' && password === 'Nazibul@1122') {
      setIsLoggedIn(true);
      setError('');
    } else {
      setError('Wrong email or password.');
    }
  };

  const saveAds = () => {
    localStorage.setItem('site_ads', JSON.stringify(ads));
    alert('Ad slots updated globally!');
  };

  const addTool = () => {
    if (!newTool.name || !newTool.slug) return alert('Fill name and slug!');
    const updated = [...customTools, { ...newTool, id: `custom-${Date.now()}` }];
    setCustomTools(updated);
    localStorage.setItem('custom_tools', JSON.stringify(updated));
    setNewTool({ name: '', description: '', slug: '', icon: 'fa-file-pdf', color: 'bg-red-500' });
    alert('Tool added! Go to home to see it.');
  };

  const deleteTool = (id: string) => {
    const updated = customTools.filter(t => t.id !== id);
    setCustomTools(updated);
    localStorage.setItem('custom_tools', JSON.stringify(updated));
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
        <div className="bg-white p-10 rounded-3xl shadow-xl max-w-sm w-full border border-gray-200">
          <h1 className="text-2xl font-black text-center mb-8 uppercase tracking-widest text-red-600">Admin Control</h1>
          <form onSubmit={handleLogin} className="space-y-6">
            <input type="email" placeholder="Email" className="w-full p-4 border rounded-xl" value={email} onChange={e => setEmail(e.target.value)} />
            <input type="password" placeholder="Password" className="w-full p-4 border rounded-xl" value={password} onChange={e => setPassword(e.target.value)} />
            {error && <p className="text-red-500 text-xs font-bold text-center">{error}</p>}
            <button className="w-full bg-[#e5322d] text-white py-4 rounded-xl font-black uppercase tracking-widest shadow-lg">Enter Dashboard</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-white border-r border-gray-200 p-8 space-y-4">
        <h2 className="text-xl font-black mb-8">Admin Panel</h2>
        <button onClick={() => setActiveTab('ads')} className={`w-full text-left p-4 rounded-xl font-bold ${activeTab === 'ads' ? 'bg-red-50 text-red-600' : 'text-gray-400'}`}>Ads Manager</button>
        <button onClick={() => setActiveTab('tools')} className={`w-full text-left p-4 rounded-xl font-bold ${activeTab === 'tools' ? 'bg-red-50 text-red-600' : 'text-gray-400'}`}>Manage Tools</button>
        <button onClick={() => setIsLoggedIn(false)} className="w-full text-left p-4 text-gray-400 font-bold hover:text-red-600">Logout</button>
      </aside>

      <main className="flex-1 p-8 md:p-12 overflow-y-auto">
        {activeTab === 'ads' && (
          <div className="max-w-4xl space-y-8">
            <h2 className="text-3xl font-black tracking-tighter">Global Ad Configuration</h2>
            <div className="grid gap-6">
              {Object.keys(ads).map(slot => (
                <div key={slot} className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">{slot.replace(/([A-Z])/g, ' $1')}</label>
                  <textarea 
                    className="w-full h-24 p-4 border rounded-xl font-mono text-xs bg-gray-50" 
                    value={(ads as any)[slot]} 
                    onChange={e => setAds({...ads, [slot]: e.target.value})}
                    placeholder="Paste Google AdSense / HTML code here..."
                  />
                </div>
              ))}
            </div>
            <button onClick={saveAds} className="bg-green-600 text-white px-12 py-4 rounded-xl font-black uppercase tracking-widest shadow-lg">Save All Ads</button>
          </div>
        )}

        {activeTab === 'tools' && (
          <div className="max-w-4xl space-y-12">
            <div className="bg-white p-10 rounded-2xl border border-gray-200 shadow-sm">
              <h2 className="text-2xl font-black mb-6">Create Custom Tool</h2>
              <div className="grid grid-cols-2 gap-4">
                <input className="p-4 border rounded-xl" placeholder="Tool Name" value={newTool.name} onChange={e => setNewTool({...newTool, name: e.target.value})} />
                <input className="p-4 border rounded-xl" placeholder="URL Slug" value={newTool.slug} onChange={e => setNewTool({...newTool, slug: e.target.value})} />
                <textarea className="col-span-2 p-4 border rounded-xl" placeholder="Description" value={newTool.description} onChange={e => setNewTool({...newTool, description: e.target.value})} />
              </div>
              <button onClick={addTool} className="mt-6 bg-blue-600 text-white px-10 py-4 rounded-xl font-black uppercase tracking-widest">Publish New Tool</button>
            </div>
            
            <div className="bg-white p-10 rounded-2xl border border-gray-200">
              <h3 className="font-black mb-6 uppercase tracking-widest text-xs text-gray-400">Current Custom Tools</h3>
              <div className="divide-y">
                {customTools.map(t => (
                  <div key={t.id} className="py-4 flex justify-between items-center">
                    <span className="font-bold text-gray-700">{t.name}</span>
                    <button onClick={() => deleteTool(t.id)} className="text-red-600 text-xs font-black uppercase tracking-widest hover:underline">Remove</button>
                  </div>
                ))}
                {customTools.length === 0 && <p className="text-gray-400 text-sm italic">No custom tools added yet.</p>}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default Admin;
