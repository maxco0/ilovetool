
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
// Fixed: Using getBlogPosts() instead of non-existent POSTS constant
import { getBlogPosts } from '../constants';
import AdSlot from '../components/AdSlot';

const Blog: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Professional PDF Guides & Articles | I l❤️ve Tool';
  }, []);

  return (
    <div className="bg-[#f3f3f3] min-h-screen pb-24">
      <section className="bg-white pt-24 pb-20 px-4 border-b border-gray-100">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-6xl font-black text-[#1a1a1a] mb-6 tracking-tighter">I l❤️ve Tool Blog</h1>
          <p className="text-2xl text-gray-400 max-w-3xl mx-auto font-medium">Expert guides, industry news, and masterclasses on professional document management.</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 mt-12">
        <AdSlot slotId="aboveContent" />
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {/* Fixed: Calling getBlogPosts() to retrieve latest blog data */}
          {getBlogPosts().map((post) => (
            <Link key={post.id} to={`/blog/${post.slug}`} className="bg-white p-8 rounded-[30px] shadow-sm border border-gray-100 hover:shadow-xl transition-all group flex flex-col h-full">
              <div className="flex justify-between items-center mb-6">
                 <span className="text-[10px] font-black uppercase tracking-[0.2em] text-red-600">{post.date}</span>
                 <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">{post.readTime} read</span>
              </div>
              <h3 className="text-2xl font-black mb-4 tracking-tight group-hover:text-red-600 transition-colors flex-grow">{post.title}</h3>
              <p className="text-gray-500 mb-8 line-clamp-3 font-medium leading-relaxed">{post.excerpt}</p>
              <div className="pt-6 border-t border-gray-50 flex items-center justify-between">
                <span className="font-bold text-xs uppercase tracking-widest">Read Article</span>
                <i className="fas fa-arrow-right text-red-600 transition-transform group-hover:translate-x-2"></i>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-20">
          <AdSlot slotId="belowContent" />
        </div>
      </div>
    </div>
  );
};

export default Blog;
