
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
// Fixed: Using getBlogPosts() instead of non-existent POSTS constant
import { getBlogPosts } from '../constants';
import { BlogPost } from '../types';
import AdSlot from '../components/AdSlot';

const BlogPostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);

  useEffect(() => {
    // Fixed: Retrieve latest posts using getBlogPosts()
    const allPosts = getBlogPosts();
    const found = allPosts.find(p => p.slug === slug);
    if (found) {
      setPost(found);
      window.scrollTo(0, 0);
      document.title = `${found.title} | I l❤️ve Tool Blog`;
    }
  }, [slug]);

  if (!post) {
    return <div className="p-20 text-center font-bold text-2xl">404: Article not found.</div>;
  }

  return (
    <div className="bg-[#f3f3f3] min-h-screen pb-24">
      <div className="bg-white pt-24 pb-20 px-4 border-b border-gray-100">
        <div className="max-w-4xl mx-auto">
          <Link to="/blog" className="text-red-600 font-bold uppercase text-xs tracking-widest mb-8 block hover:underline">
            <i className="fas fa-arrow-left mr-2"></i> Back to Blog
          </Link>
          <h1 className="text-5xl md:text-6xl font-black text-[#1a1a1a] mb-8 tracking-tighter leading-tight">{post.title}</h1>
          <div className="flex items-center gap-8 border-t border-gray-100 pt-8">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white font-black text-xl mr-4">{post.author[0]}</div>
              <div>
                <p className="font-black text-sm">{post.author}</p>
                <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">Lead Strategist</p>
              </div>
            </div>
            <div className="h-8 w-px bg-gray-100"></div>
            <div>
              <p className="font-black text-sm">{post.date}</p>
              <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">{post.readTime} Reading Time</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-12 grid lg:grid-cols-[1fr_300px] gap-12">
        <article className="bg-white p-12 md:p-20 rounded-[40px] shadow-sm border border-gray-100">
           <AdSlot slotId="aboveContent" className="mb-12" />
           <div 
             className="content-article" 
             dangerouslySetInnerHTML={{ __html: post.content }}
           />
           <AdSlot slotId="belowContent" className="mt-12" />
        </article>

        <aside className="space-y-8">
           <div className="sticky top-24 space-y-8">
              <AdSlot slotId="sidebar" />
              <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <h4 className="font-black text-xl mb-6 tracking-tight">Recent Articles</h4>
                <div className="space-y-6">
                  {/* Fixed: Use getBlogPosts() to find related articles */}
                  {getBlogPosts().filter(p => p.id !== post.id).slice(0, 3).map(rp => (
                    <Link key={rp.id} to={`/blog/${rp.slug}`} className="block group">
                      <h5 className="font-bold text-sm leading-snug group-hover:text-red-600 transition-colors">{rp.title}</h5>
                      <p className="text-[10px] text-gray-400 font-bold uppercase mt-2 tracking-widest">{rp.date}</p>
                    </Link>
                  ))}
                </div>
              </div>
              <div className="bg-[#e5322d] p-8 rounded-3xl text-white shadow-xl shadow-red-100">
                <h4 className="font-black text-2xl mb-4 tracking-tight">Need to Merge?</h4>
                <p className="text-sm opacity-80 mb-6 font-medium">The world's fastest PDF merger is just one click away. No registration required.</p>
                <Link to="/merge-pdf" className="inline-block bg-white text-red-600 px-6 py-3 rounded-xl font-black uppercase text-xs tracking-widest hover:bg-gray-50 transition-all">Start Now</Link>
              </div>
           </div>
        </aside>
      </div>
    </div>
  );
};

export default BlogPostPage;
