
import React, { useState } from 'react';
// Fixed: Using getTools() instead of non-existent TOOLS constant
import { getTools } from '../constants';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    tool: 'general',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call to Node.js backend
    console.log('Sending email to: nazibulmaxco1@gmail.com');
    console.log('Data:', formData);
    setSubmitted(true);
  };

  return (
    <div className="bg-white min-h-screen py-24 px-6">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-20">
        <div className="content-article space-y-10">
          <h1 className="text-6xl font-black tracking-tighter mb-8 leading-tight">Get in Touch with the I Love Tool Experts</h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Whether you're a student, a freelancer, or a representative from a Fortune 500 company, we value your feedback and inquiries. Our mission is to make <strong>I Love Tool</strong> the most reliable document suite on the planet, and your input is the key to our success.
          </p>
          
          <section>
            <h2 className="text-3xl font-black mb-6">Technical Support and Bug Reporting</h2>
            <p>
              Encountered a glitch while trying to <strong>Merge PDF</strong> files? Or perhaps a <strong>PDF to Word</strong> conversion didn't preserve a specific font? Our technical support team is comprised of senior engineers who understand the complexities of document structures. When you report a bug, we don't just send an automated response; we investigate the processing logs of our <strong>Ghostscript</strong> and <strong>LibreOffice</strong> engines to find the root cause.
            </p>
            <p>
              To help us resolve your issue faster, please include the specific tool name, the size of the file you were processing, and any error codes shown on the <strong>ProcessingUI</strong>. We strive to respond to all technical tickets within 12 business hours.
            </p>
          </section>

          <section>
            <h2 className="text-3xl font-black mb-6">Enterprise Inquiries and API Access</h2>
            <p>
              Are you looking to integrate the power of <strong>I Love Tool</strong> directly into your own applications? We offer custom API solutions for high-volume <strong>Compress PDF</strong>, <strong>Protect PDF</strong>, and conversion tasks. Our backend is designed for scalability, capable of handling tens of thousands of requests per second.
            </p>
            <p>
              By choosing our enterprise tier, you benefit from dedicated server instances, priority processing, and white-label options. Contact us today to discuss how we can build a custom document workflow that fits your specific business needs.
            </p>
          </section>

          <section>
            <h2 className="text-3xl font-black mb-6">Feature Requests and Suggestions</h2>
            <p>
              The best tools are built by their users. If you think we're missing a critical feature—like a specific <strong>Scan to PDF</strong> mode or an advanced <strong>HTML to PDF</strong> scraper—we want to hear about it. Many of our most popular tools, including <strong>Unlock PDF</strong> and <strong>Watermark PDF</strong>, were developed based on direct user feedback.
            </p>
            <p>
              We maintain a transparent roadmap and regularly update our community on upcoming releases. Your suggestion could be the next "Big Red Button" on our homepage.
            </p>
          </section>

          <section>
            <h2 className="text-3xl font-black mb-6">Privacy and Security Concerns</h2>
            <p>
              Your trust is our most valuable asset. If you have questions about our <strong>2-Hour Auto-Delete</strong> policy, our encryption standards, or how we maintain <strong>GDPR compliance</strong>, our security officer is available to provide detailed explanations. We are committed to transparency and are happy to share more about our internal data handling protocols.
            </p>
          </section>
        </div>

        <div className="relative">
          <div className="sticky top-24 bg-gray-50 p-12 rounded-3xl shadow-2xl border border-gray-100">
            {submitted ? (
              <div className="text-center py-20 animate-in fade-in zoom-in duration-500">
                <div className="w-24 h-24 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-10 text-5xl shadow-xl shadow-green-100">
                  <i className="fas fa-paper-plane"></i>
                </div>
                <h2 className="text-4xl font-black mb-6 tracking-tighter">Message Delivered!</h2>
                <p className="text-gray-600 text-lg font-medium leading-relaxed mb-10">
                  Thank you for reaching out to <strong>I Love Tool</strong>. A member of our senior engineering team will review your message and get back to you shortly.
                </p>
                <button 
                  onClick={() => setSubmitted(false)} 
                  className="text-[#e5322d] font-black uppercase tracking-widest text-sm hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Your Full Name</label>
                    <input 
                      required 
                      type="text" 
                      className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:ring-4 focus:ring-red-50 focus:border-[#e5322d] outline-none transition-all font-medium" 
                      placeholder="John Doe" 
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Email Address</label>
                    <input 
                      required 
                      type="email" 
                      className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:ring-4 focus:ring-red-50 focus:border-[#e5322d] outline-none transition-all font-medium" 
                      placeholder="john@example.com" 
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Select Relevant Tool</label>
                  <select 
                    className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:ring-4 focus:ring-red-50 focus:border-[#e5322d] outline-none transition-all font-bold text-gray-700 appearance-none bg-white"
                    value={formData.tool}
                    onChange={(e) => setFormData({...formData, tool: e.target.value})}
                  >
                    <option value="general">General Support</option>
                    <option value="enterprise">Enterprise / API Inquiry</option>
                    {/* Fixed: Calling getTools() to map available tools */}
                    {getTools().map(tool => (
                      <option key={tool.id} value={tool.id}>{tool.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Detailed Message</label>
                  <textarea 
                    required 
                    rows={8} 
                    className="w-full px-6 py-4 rounded-xl border border-gray-200 focus:ring-4 focus:ring-red-50 focus:border-[#e5322d] outline-none transition-all font-medium resize-none" 
                    placeholder="Tell us exactly how we can help..."
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-[#e5322d] text-white py-6 rounded-xl font-black text-2xl hover:bg-[#c42723] transition-all shadow-2xl shadow-red-200 uppercase tracking-tighter"
                >
                  Submit Inquiry <i className="fas fa-arrow-right ml-3"></i>
                </button>
                <p className="text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                  Protected by 256-bit SSL encryption
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
