
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getTools, DEFAULT_TOOLS } from '../constants';
import AdSlot from '../components/AdSlot';

const Home: React.FC = () => {
  // Directly pull from constants as fallback to ensure the UI is never empty
  const [tools, setTools] = useState(() => {
    const list = getTools();
    return list.length > 0 ? list : DEFAULT_TOOLS;
  });

  useEffect(() => {
    document.title = 'I Love Tool | Every Tool you need for PDFs';
    // Re-check in case custom tools were added
    const latest = getTools();
    if (latest.length > 0) {
      setTools(latest);
    }
  }, []);

  return (
    <div className="bg-[#f3f3f3] min-h-screen pb-24 font-sans">
      <AdSlot slotId="globalHeader" />
      
      {/* Hero Section */}
      <section className="bg-white pt-12 md:pt-16 pb-10 md:pb-12 px-4 text-center">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl md:text-5xl font-black text-[#1a1a1a] mb-4 tracking-tighter">
            Every tool you need to work with PDFs in one place
          </h1>
          <p className="text-sm md:text-lg text-gray-500 max-w-4xl mx-auto mb-10 font-medium leading-tight">
            Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use! Merge, split, compress, convert, rotate, unlock and watermark PDFs with just a few clicks.
          </p>
          
          {/* Categories Bar */}
          <div className="flex flex-wrap justify-center gap-2 mb-8 md:mb-10">
            {['All', 'Workflows', 'Organize PDF', 'Optimize PDF', 'Convert PDF', 'Edit PDF', 'PDF Security'].map((cat, i) => (
              <button key={i} className={`px-4 py-1.5 rounded-full text-[11px] font-black uppercase tracking-wider border transition-all ${i === 0 ? 'bg-[#333] text-white border-[#333]' : 'bg-white text-gray-600 border-gray-200 hover:border-red-500'}`}>
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 mt-6">
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-4 md:gap-6">
          {tools && tools.length > 0 ? (
            tools.map((tool) => (
              <Link 
                key={tool.id || tool.slug} 
                to={`/${tool.slug}`}
                className="bg-white p-4 md:p-6 flex flex-col items-start text-left shadow-sm hover:shadow-xl transition-all duration-200 border border-gray-100 hover:border-red-200 group rounded-xl h-full"
              >
                <div className={`w-10 h-10 md:w-12 md:h-12 flex items-center justify-center mb-3 rounded-lg text-white text-lg md:text-xl ${tool.color || 'bg-red-500'} shadow-sm group-hover:scale-105 transition-transform`}>
                  <i className={`fas ${tool.icon || 'fa-file-pdf'}`}></i>
                </div>
                <h3 className="text-[14px] md:text-[15px] font-black text-gray-900 mb-1 leading-tight group-hover:text-red-600 transition-colors uppercase tracking-tighter">{tool.name}</h3>
                <p className="text-[10px] md:text-[11px] text-gray-400 leading-snug font-medium line-clamp-3">{tool.description}</p>
              </Link>
            ))
          ) : (
             <div className="col-span-full py-20 text-center">
                <p className="text-gray-400 font-bold">Initializing tools engine...</p>
             </div>
          )}
          
          {/* Workflow Card Mockup */}
          <div className="bg-[#fff1f1] p-6 flex flex-col items-start text-left border border-red-100 rounded-xl h-full relative overflow-hidden group cursor-pointer hidden md:flex">
             <h3 className="text-lg font-black text-red-600 mb-2 leading-tight">Create a workflow</h3>
             <p className="text-xs text-red-400 font-medium">Create custom workflows with your favorite tools.</p>
             <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-red-200 rounded-full opacity-20 group-hover:scale-150 transition-transform"></div>
          </div>
        </div>
      </section>

      {/* Articles Section */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 mt-24">
        <div className="flex justify-between items-center mb-8 border-b border-gray-200 pb-4">
          <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Professional Insights</h2>
          <Link to="/blog" className="text-red-600 font-bold text-xs uppercase tracking-widest hover:underline">View All</Link>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
           <Link to="/blog/best-ilovepdf-alternative-2024" className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all group">
             <span className="text-[10px] font-black uppercase text-red-600 block mb-2">Editor's Choice</span>
             <h3 className="text-xl font-black mb-3 group-hover:text-red-600 transition-colors">Why I l❤️ve Tool is the #1 Choice in 2024</h3>
             <p className="text-gray-400 text-sm leading-relaxed">A deep dive into why our engine outperforms legacy platforms.</p>
           </Link>
           <Link to="/blog/compress-pdf-without-losing-quality" className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all group">
             <span className="text-[10px] font-black uppercase text-red-600 block mb-2">Technical Guide</span>
             <h3 className="text-xl font-black mb-3 group-hover:text-red-600 transition-colors">Mastering PDF Compression</h3>
             <p className="text-gray-400 text-sm leading-relaxed">Learn how to shrink files by 90% while keeping text crisp.</p>
           </Link>
        </div>
      </section>
      
      <AdSlot slotId="footer" className="mt-20" />
    </div>
  );
};

export default Home;
