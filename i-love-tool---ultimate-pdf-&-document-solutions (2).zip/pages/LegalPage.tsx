
import React, { useEffect } from 'react';

interface LegalPageProps {
  title: string;
  type: 'privacy' | 'terms' | 'about' | 'disclaimer' | 'copyright';
}

const LegalPage: React.FC<LegalPageProps> = ({ title, type }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `${title} | I l❤️ve Tool`;
  }, [title]);

  return (
    <div className="bg-white min-h-screen py-24 px-6">
      <div className="max-w-5xl mx-auto content-article">
        <h1 className="text-6xl font-black mb-12 text-gray-900 border-b-8 border-[#e5322d] pb-8 tracking-tighter inline-block">{title}</h1>
        
        {type === 'about' && (
          <div className="space-y-12">
            <p className="text-2xl font-bold text-gray-700 leading-relaxed italic border-l-4 border-[#e5322d] pl-6 mb-10">
              "I l❤️ve Tool was built on the belief that powerful document processing should be accessible to everyone, everywhere, without the barrier of high costs or complex software installations."
            </p>
            <h2 className="text-3xl font-black mb-6">The True Story of Our Mission</h2>
            <p>
              In the modern age, the PDF format has become the lifeblood of global communication. Every contract, every academic paper, and every corporate report travels across the world as a PDF. However, for decades, the keys to this format were held by a few massive software giants who charged exorbitant subscription fees for basic tasks. We saw students struggling to merge their homework assignments, small business owners being billed monthly just to sign a contract, and designers unable to compress their portfolios for email.
            </p>
            <p>
              This is why <strong>I l❤️ve Tool</strong> exists. Our founder, Nazibul, envisioned a platform where the most sophisticated backend engines—Ghostscript, LibreOffice, and PDFCPU—were wrapped in a simple, beautiful, and 100% free interface. We didn't want to create just another converter; we wanted to create a utility that felt like it belonged in the hands of the people.
            </p>
            <h2 className="text-3xl font-black">Engineering Excellence and Security</h2>
            <p>
              Our engineering team spent thousands of hours optimizing our cloud infrastructure. While other sites use weak JavaScript libraries that run in your browser and often crash, we route every request through high-performance server clusters. This allows us to handle huge files and complex formatting with 99.9% accuracy.
            </p>
            <p>
              But power is nothing without trust. We pioneered the <strong>Zero-Retention Policy</strong>. In a world where your data is often the product, we treat your documents like toxic waste: we want them processed and gone as fast as possible. Our system automatically scrubs every file from our servers after exactly 120 minutes. We don't read them, we don't save them, and we certainly don't sell them. This commitment to ethics has made us the primary choice for legal firms and medical researchers worldwide.
            </p>
            <p>
              [Additional 2000 words would go here describing the team, the global server network, the future of OCR integration, and the philosophy of open-source document freedom...]
            </p>
          </div>
        )}

        {type === 'privacy' && (
          <div className="space-y-12">
            <h2 className="text-3xl font-black">Comprehensive Privacy and Data Protection Policy</h2>
            <p>
              Welcome to the Privacy Policy of <strong>I l❤️ve Tool</strong>. Your privacy is our absolute priority. This document outlines our rigorous protocols for data handling, encryption, and your rights as a user. We operate under the strictest international data protection regulations, including the General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA).
            </p>
            <h2 className="text-3xl font-black">1. Document Processing and Ephemeral Storage</h2>
            <p>
              When you upload a file to perform a <strong>Merge PDF</strong> or <strong>Compress PDF</strong> task, your data is transmitted over a secure 256-bit SSL encrypted connection. Once it reaches our server, it is placed in an isolated virtual container. This container is destroyed as soon as your task is complete or after a maximum of two hours. 
            </p>
            <p>
              We do not monitor, analyze, or categorize the content of your files. Our servers are "content-blind"—they see binary data, process it according to your instructions, and then purge it. We do not maintain any backups or shadows of your documents. Once deleted, they are unrecoverable.
            </p>
            <h2 className="text-3xl font-black">2. Cookies, Analytics, and AdSense</h2>
            <p>
              To support our free service, we display advertisements via Google AdSense. These partners may use cookies to serve personalized ads. We also use minimal analytics to measure server load and improve the user journey. We do not use intrusive cross-site tracking or fingerprinting. You can opt-out of these cookies via your browser settings at any time without losing access to our tools.
            </p>
            <p>
              [Continuing with 2000+ words detail on server locations, incident response plans, employee data access restrictions, and legal disclosures...]
            </p>
          </div>
        )}

        {type === 'terms' && (
          <div className="space-y-12">
            <h2 className="text-3xl font-black">Terms of Service and User License Agreement</h2>
            <p>
              By accessing <strong>I l❤️ve Tool</strong>, you agree to be bound by these professional Terms of Service. This agreement governs your use of our PDF manipulation utilities, conversion engines, and all related content.
            </p>
            <h2 className="text-3xl font-black">1. Grant of License</h2>
            <p>
              We grant you a non-exclusive, non-transferable, temporary license to use our tools for personal and commercial document processing. You retain 100% ownership of any data you upload. <strong>I l❤️ve Tool</strong> makes no claim to your intellectual property.
            </p>
            <h2 className="text-3xl font-black">2. Prohibited Uses</h2>
            <p>
              You agree not to use our service to process documents containing illegal content, malware, or content that infringes on third-party copyrights. You may not attempt to reverse engineer our proprietary conversion algorithms or use automated scripts to "scrape" our service. Any violation of these terms will result in an immediate IP ban.
            </p>
            <p>
              [Additional 2200 words on liability limits, indemnity clauses, service availability, and dispute resolution...]
            </p>
          </div>
        )}

        {type === 'disclaimer' && (
          <div className="space-y-12">
            <h2 className="text-3xl font-black">Legal Disclaimer and Liability Statement</h2>
            <p>
              The information and tools provided by <strong>I l❤️ve Tool</strong> are provided "as is" and without warranties of any kind. While our engines are the most advanced in the industry, document processing is an imperfect science.
            </p>
            <h2 className="text-3xl font-black">1. Accuracy and Formatting</h2>
            <p>
              We strive for 100% accuracy in our <strong>PDF to Word</strong> and <strong>Excel to PDF</strong> conversions. However, due to the variance in PDF generation standards, we cannot guarantee that every layout, font, or embedded image will be preserved exactly as intended in the destination format. Users are encouraged to review all processed files before finalizing professional or legal submissions.
            </p>
            <h2 className="text-3xl font-black">2. Service Liability</h2>
            <p>
              <strong>I l❤️ve Tool</strong> is not responsible for any loss of data, loss of business, or missed deadlines resulting from the use or inability to use our services. We do not provide long-term storage; if you fail to download your file within the 2-hour window, we cannot retrieve it.
            </p>
            <p>
              [2300+ words on jurisdictional specifics, third-party software dependencies, and emergency maintenance notices...]
            </p>
          </div>
        )}

        {type === 'copyright' && (
          <div className="space-y-12">
            <h2 className="text-3xl font-black">Copyright Notice and DMCA Policy</h2>
            <p>
              All content on the <strong>I l❤️ve Tool</strong> website, including but not limited to text, graphics, logos, icons, images, and software, is the property of I l❤️ve Tool and is protected by international copyright laws.
            </p>
            <h2 className="text-3xl font-black">1. Trademarks and UI Design</h2>
            <p>
              The "I l❤️ve Tool" brand name, the heart-themed logo, and the specific layout of our tool cards are proprietary intellectual property. Any unauthorized reproduction, imitation, or redistribution is strictly prohibited and will be met with legal action.
            </p>
            <h2 className="text-3xl font-black">2. DMCA Compliance</h2>
            <p>
              We respect the intellectual property rights of others. If you believe your copyrighted work has been processed through our tools in a way that constitutes infringement, please contact our DMCA agent. Note that since we delete files every 2 hours, we do not host infringing content; however, we take all reports seriously to prevent system abuse.
            </p>
            <p>
              [2400+ words on user content ownership, fair use guidelines, and international IP enforcement procedures...]
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LegalPage;
