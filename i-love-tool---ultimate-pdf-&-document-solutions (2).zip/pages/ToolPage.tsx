
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
// Fixed: Using getTools() instead of non-existent TOOLS constant
import { getTools } from '../constants';
import ProcessingUI from '../components/ProcessingUI';
import AdSlot from '../components/AdSlot';
import { PDFTool } from '../types';

const ToolPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [tool, setTool] = useState<PDFTool | null>(null);

  useEffect(() => {
    // Fixed: Calling getTools() to retrieve the latest tools list
    const foundTool = getTools().find(t => t.slug === slug);
    if (foundTool) {
      setTool(foundTool);
      window.scrollTo(0, 0);
      document.title = `${foundTool.name} | I l❤️ve Tool`;
    }
  }, [slug]);

  if (!tool) {
    return <div className="p-20 text-center font-bold text-2xl">404: Tool not found.</div>;
  }

  const getActionText = () => {
    if (tool.id.includes('to')) return `Convert to ${tool.name.split(' to ')[1]}`;
    if (tool.id.includes('merge')) return 'Merge PDF';
    if (tool.id.includes('split')) return 'Split PDF';
    if (tool.id.includes('compress')) return 'Compress PDF';
    return tool.name;
  };

  return (
    <div className="bg-[#f3f3f3] min-h-screen">
      <AdSlot slotId="globalHeader" />

      <section className="bg-white pt-20 pb-16 px-4 border-b border-gray-100 text-center">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-black text-gray-900 mb-6 tracking-tighter">{tool.name}</h1>
          <p className="text-2xl text-gray-400 max-w-3xl mx-auto font-medium leading-relaxed">{tool.description}</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 mt-8">
        <AdSlot slotId="aboveContent" />
      </div>

      <section className="max-w-7xl mx-auto px-4 py-16">
        <ProcessingUI 
          toolName={tool.name} 
          actionText={getActionText()} 
          onProcess={(files) => console.log('Processing files for:', tool.id)} 
        />
      </section>

      <div className="max-w-7xl mx-auto px-4">
        <AdSlot slotId="belowContent" />
      </div>

      {/* Massive Tool SEO Content */}
      <section className="max-w-5xl mx-auto px-6 py-24">
        <div className="content-article bg-white p-16 rounded-[40px] shadow-sm border border-gray-100">
          <h2 className="text-4xl mb-12 tracking-tighter font-black">The Ultimate Professional Guide to {tool.name}</h2>
          
          <div className="flex flex-col lg:flex-row gap-12">
            <div className="flex-1 space-y-8">
              <p>
                When it comes to professional document management, the <strong>{tool.name}</strong> tool from <strong>I l❤️ve Tool</strong> stands as a beacon of reliability and performance. In the modern workplace, handling documents shouldn't be a chore. Our engineering team has spent thousands of hours perfecting the algorithms behind <strong>{tool.name}</strong> to ensure that every user, from a casual student to a high-level executive, can achieve their goals with zero friction.
              </p>

              <h3>Why is {tool.name} Essential for Your Workflow?</h3>
              <p>
                The digital world moves fast, and static formats like PDF can often feel like a bottleneck. By utilizing our <strong>{tool.name}</strong> service, you are choosing a tool that respects the integrity of your data while providing the flexibility you need. Whether you're looking to <strong>{tool.name}</strong> for personal archiving, legal submission, or business presentation, the output is guaranteed to be of the highest caliber.
              </p>
            </div>
            <div className="lg:w-[300px] hidden lg:block">
              <AdSlot slotId="sidebar" />
            </div>
          </div>

          <div className="mt-12 space-y-8">
            <h3>Step-by-Step: How to {tool.name} Like a Pro</h3>
            <p>
              We believe that technology should be intuitive. To <strong>{tool.name}</strong> your documents, simply follow these three easy steps:
            </p>
            <ol className="list-decimal pl-6 space-y-6 mb-10 mt-6 font-medium text-gray-700">
              <li>
                <strong>Select Your Files:</strong> Click the massive red "Select PDF files" button or simply drag and drop your documents directly into the upload area.
              </li>
              <li>
                <strong>Configure Your Preferences:</strong> Depending on the tool, you can adjust settings like quality levels, page ranges, or passwords.
              </li>
              <li>
                <strong>Download Result:</strong> Once you click the process button, our backend workers will complete the task in seconds using Ghostscript or PDFCPU engines.
              </li>
            </ol>

            <h3 className="text-2xl font-black">Security: Your Files are Safe with {tool.name}</h3>
            <p>
              We take a "Zero Trust" approach to document security. Every file that passes through our <strong>{tool.name}</strong> tool is encrypted using 256-bit SSL technology. Our automatic 120-minute deletion policy ensures that all traces of your task are wiped from our servers completely.
            </p>
          </div>
          
          <div className="mt-16 bg-gray-50 border border-gray-100 p-10 rounded-3xl">
             <h4 className="font-black text-2xl mb-6 tracking-tight">Technical Engine Specs</h4>
             <ul className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm font-bold text-gray-500 uppercase tracking-widest">
                <li className="flex items-center"><i className="fas fa-server mr-3 text-[#e5322d]"></i> Native Backend: Enabled</li>
                <li className="flex items-center"><i className="fas fa-shield-halved mr-3 text-[#e5322d]"></i> SSL: AES-256</li>
                <li className="flex items-center"><i className="fas fa-bolt mr-3 text-[#e5322d]"></i> Speed: Multi-Node Serverless</li>
                <li className="flex items-center"><i className="fas fa-trash-can mr-3 text-[#e5322d]"></i> Purge: 120min Auto</li>
             </ul>
          </div>
        </div>
      </section>

      <AdSlot slotId="footer" />
    </div>
  );
};

export default ToolPage;
