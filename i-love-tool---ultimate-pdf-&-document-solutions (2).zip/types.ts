
export enum ToolCategory {
  ORGANIZE = 'Organize PDF',
  OPTIMIZE = 'Optimize PDF',
  CONVERT_FROM = 'Convert to PDF',
  CONVERT_TO = 'Convert from PDF',
  EDIT = 'Edit PDF',
  SECURITY = 'PDF Security'
}

export interface PDFTool {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: ToolCategory;
  slug: string;
  color: string;
  isCustom?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  readTime: string;
}

export interface NavLink {
  label: string;
  href: string;
}

export interface AdSlots {
  globalHeader: string;
  aboveContent: string;
  belowContent: string;
  footer: string;
  sidebar: string;
}
